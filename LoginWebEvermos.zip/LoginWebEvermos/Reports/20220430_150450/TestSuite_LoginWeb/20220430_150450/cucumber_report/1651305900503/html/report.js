$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Mutiara/Katalon/LoginWebEvermos/Include/features/LoginWeb.feature");
formatter.feature({
  "name": "LoginWeb",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@EvermosLoginFeature"
    }
  ]
});
formatter.scenarioOutline({
  "name": "User login menggunakan invalid password",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@test"
    }
  ]
});
formatter.step({
  "name": "User mengisi \u003cnoHP\u003e yang benar dan invalid \u003cpassword\u003e",
  "keyword": "When "
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.step({
  "name": "User akan melihat error \u0027Nomor Telepon atau Kata Sandi anda salah!\u0027",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "noHP",
        "password"
      ]
    },
    {
      "cells": [
        "6282113225667",
        "udncYyUJ+jmW3Lvnsj5JXQ\u003d\u003d"
      ]
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "User membuka https://evermos.com",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginWeb.openEvermos()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik Masuk",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.klikMasuk()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User login menggunakan invalid password",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@EvermosLoginFeature"
    },
    {
      "name": "@test"
    }
  ]
});
formatter.step({
  "name": "User mengisi 6282113225667 yang benar dan invalid udncYyUJ+jmW3Lvnsj5JXQ\u003d\u003d",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.memasukkanInvalidPassword(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.match({
  "location": "LoginWeb.klikLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User akan melihat error \u0027Nomor Telepon atau Kata Sandi anda salah!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginWeb.invalidPasswordMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "User login menggunakan invalid No. HP",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "User mengisi \u003cnoHP\u003e yang invalid dan \u003cpassword\u003e yang benar",
  "keyword": "When "
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.step({
  "name": "User akan melihat error \u0027Nomor ini belum terdaftar sebagai reseller\u0027",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "noHP",
        "password"
      ]
    },
    {
      "cells": [
        "6282113225699",
        "jn9+/dk/dX7MRyy6+wlneA\u003d\u003d"
      ]
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "User membuka https://evermos.com",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginWeb.openEvermos()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik Masuk",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.klikMasuk()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User login menggunakan invalid No. HP",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@EvermosLoginFeature"
    }
  ]
});
formatter.step({
  "name": "User mengisi 6282113225699 yang invalid dan jn9+/dk/dX7MRyy6+wlneA\u003d\u003d yang benar",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.memasukkanInvalidNoHP(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.match({
  "location": "LoginWeb.klikLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User akan melihat error \u0027Nomor ini belum terdaftar sebagai reseller\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginWeb.invalidNoHPMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "User melakukan login dengan benar",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "User mengisi \u003cnoHP\u003e yang sudah terdaftar and \u003cpassword\u003e yang benar",
  "keyword": "When "
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.step({
  "name": "User berhasil login and masuk ke halaman beranda",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "noHP",
        "password"
      ]
    },
    {
      "cells": [
        "6282113225667",
        "jn9+/dk/dX7MRyy6+wlneA\u003d\u003d"
      ]
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "User membuka https://evermos.com",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginWeb.openEvermos()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik Masuk",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.klikMasuk()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User melakukan login dengan benar",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@EvermosLoginFeature"
    }
  ]
});
formatter.step({
  "name": "User mengisi 6282113225667 yang sudah terdaftar and jn9+/dk/dX7MRyy6+wlneA\u003d\u003d yang benar",
  "keyword": "When "
});
formatter.match({
  "location": "LoginWeb.memasukkanDataValid(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User klik tombol login",
  "keyword": "And "
});
formatter.match({
  "location": "LoginWeb.klikLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User berhasil login and masuk ke halaman beranda",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginWeb.beranda()"
});
formatter.result({
  "status": "passed"
});
});