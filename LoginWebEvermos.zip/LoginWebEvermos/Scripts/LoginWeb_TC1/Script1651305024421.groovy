import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://evermos.com/home/')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Evermos Reseller online dan aplikasi D_3b84c7/a_Masuk'))

WebUI.setText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Nomor Telepon_inputText__input'), 
    '6282113225667')

WebUI.setEncryptedText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Kata Sandi_inputText__input'), 
    'udncYyUJ+jmW3Lvnsj5JXQ==')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/button_Masuk'))

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/p_Nomor Telepon atau Kata Sandi anda salah'))

WebUI.closeBrowser()

WebUI.openBrowser('')

WebUI.navigateToUrl('https://evermos.com/home/')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Evermos Reseller online dan aplikasi D_3b84c7/a_Masuk'))

WebUI.setText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Nomor Telepon_inputText__input'), 
    '6282113225668')

WebUI.setEncryptedText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Kata Sandi_inputText__input'), 
    'EkiSKim6QgXI8ZbwsnvuaA==')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/button_Masuk'))

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/p_Nomor ini belum terdaftar sebagai reseller'))

WebUI.closeBrowser()

WebUI.openBrowser('')

WebUI.navigateToUrl('https://evermos.com/home/')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Evermos Reseller online dan aplikasi D_3b84c7/a_Masuk'))

WebUI.setText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Nomor Telepon_inputText__input'), 
    '6282113225667')

WebUI.setEncryptedText(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/input_Kata Sandi_inputText__input'), 
    'jn9+/dk/dX7MRyy6+wlneA==')

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Masuk Sebagai Reseller Evermos/button_Masuk'))

WebUI.click(findTestObject('Object Repository/EvermosLoginWeb/Page_Evermos - Katalog/button_LAIN KALI'))

WebUI.closeBrowser()

